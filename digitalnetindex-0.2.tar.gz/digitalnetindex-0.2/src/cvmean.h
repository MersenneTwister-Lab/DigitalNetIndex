#pragma once
#ifndef CVMEAN_H
#define CVMEAN_H

double calc_c_for_cvmean(int s, int n);

#endif // CVMEAN_H
